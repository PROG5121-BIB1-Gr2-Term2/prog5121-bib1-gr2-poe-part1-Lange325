package Registration;

import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {
    //Check user name testing
    
    @Test
    public void testValidUserName() {
        assertTrue(Login.checkUserName("ky1_1"));
    }

    @Test
    public void testInvalidUserName() {
        assertFalse(Login.checkUserName("kyle!!!!!!!"));
    }

    //check password complexity tests
    @Test
    public void testValidPassword() {
        assertTrue(Login.checkPasswordComplexity("Ch@eck$be99!"));
    }

    @Test
    public void testValidPassword() {
        assertFalse(Login.checkPasswordComplexity("password"));
    }

    // check cell number tests
    @Test
    public void testValidCellNumber() {
        assertTrue(Login.checkCellNumber("+27831234567"));
    }

    @Test
    public void testValidCellNumber() {
        assertFalse(Login.checkPhoneNumber("+27988312345"));
    }

    //registerUser tests
    @Test
    public void testRegisterUserMessages() {
        Login login = new Login()
        String result = login.registerUser("ky1_1", "Ch@eck$be99!", "+27831234567");
        assertEquals("Password is not correctly formatted, please ensure that the password contains at least 8 characters.")
    }

    //login user (logic) tests
    @Test
    void testLoginUserSuccess() {
        assertTrue(Login.LoginUser("ky1_1", "Ch@eck$be99!"));
    }

    @Test
    void testLoginUserWrongPassword() {
        assertFalse(Login.LoginUser("ky1_1", "wrongPass"));
    }

    @Test
    void testLoginUserWrongUsername() {
        assertFalse(Login.LoginUser("wrongUser", "Ch@eck$be99!"));
    }

    //return login status tests
    @Test
    void testReturnLoginStatusSuccess() {
        String msg = login.returnLoginStatus(true, "John", "Doe");
        assertEquals("Welcome John Doe, it is great to see you again!", msg);
    }

    @Test
    void testReturnLoginStatusFailure() {
        String msg = login.returnLoginStatus(false, "John", "Doe");
        assertEquals("Username or password incorrect, please try again", msg);
    }
}

