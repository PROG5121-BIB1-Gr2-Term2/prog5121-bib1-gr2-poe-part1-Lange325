package registration;

import javax.swing.JOptionPane;

public class Registration {
//Declaring the variables 
    private String firstName;
    private String lastName;
    private String cellNo;
    private String userName;
    private String password;
    
    public static void main (String[] args) {
        Registration registration = new Registration();
        registration.startRegistration();
    }
    public void startRegistration(){
        //prompting the user to enter the information
        firstName = JOptionPane.showInputDialog("Please enter your first name");
        
        lastName = JOptionPane.showInputDialog("Please enter your last name");
        
        //enter unique details with validation
        userName = getValidUsername();
        
        password = getValidPassword();
        
        cellNo = getValidCellNumber();
        
        //show successful registration message when entered
        JOptionPane.showMessageDialog(null,
        "Registration successful!\n"+
        "First Name: "+ firstName + "\n"+
        "First Name: "+ lastName + "\n"+
        "Username: "+ userName + "\n"+
        "Phone: "+ cellNo);
    }
    //Prompting the user to enter what is asked for
    
    //Asking users to enter their name and surname
    private String getValidUsername() {
    String username;
    do {
    username= JOptionPane.showInputDialog("Enter username (must be <= 5 characters and contain'_'):"); 
    }
      while (!isValidUsername(username));
    return username;
    }
    
    private boolean isValidUsername(String username){
      if (username.length()> 5|| !username.contains("_")){
      JOptionPane.showMessageDialog(null,
       "Username must be <= 5 characters and contain'_'");
      return false;
      }
      return true;
    }
    //The user entering the password as asked
    private String getValidPassword() {
       String password;
       do{ 
           password = JOptionPane.showInputDialog(
           "Enter password (must be >= 8 characters with:\n" + "- 1 capital letter\n - 1 special character):");
       } while (! isValidPassword(password));
       return password;
    }
    private boolean isValidPassword (String password){
    boolean hasNumber = false;
    boolean hasCapital = false;
    boolean hasSpecialCharacters = false;
    
    if (password.length()< 8){
    showPasswordError();
    return false;
    }
    for (char c: password.toCharArray()){
    if (Character.isDigit(c))hasNumber = true;
    if (Character.isUpperCase(c))hasCapital = true;
    if (!Character.isLetterOrDigit(c))hasSpecialCharacters = true;
    }
    if (!(hasNumber && hasCapital && hasSpecialCharacters)) {
    showPasswordError();
    return false;
    }
    return true;
    }
    private void showPasswordError(){
    JOptionPane.showMessageDialog(null,
    "Password must contain:\n"+ 
     "-At least 8 characters\n"+
     "-1 capital letter\n"+
      "-1 number\n"+
      "-1 special character");
    }
    //Restiction for users to follow when entering their cell numbers
    private String getValidCellNumber(){
     String cellNo;
     do{
         cellNo=JOptionPane.showInputDialog(
         "Enter phone number (must start with +27 and be 9 digits long):");
     }
     while(!isValidCellNumber(cellNo));
     return cellNo;
    }
    private boolean isValidCellNumber(String cellNo){
     if (cellNo == null){
      return false;   
     }  
     if (!cellNo.matches("\\+27\\d{9}")){
         JOptionPane.showMessageDialog(null, "Phone number must start with +27 and contain exactly 9 digits\n"+"Example +27324867590");
         return false;
     }
     return true;
     }
    }         