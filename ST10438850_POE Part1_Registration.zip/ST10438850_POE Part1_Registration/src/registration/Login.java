/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registration;

import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class Login {
 public static boolean checkUserName(String userName) {
        return userName.length() <= 5 && userName.contains("_");
    }
//Having restriction to the password being entered
    public static boolean checkPasswordComplexity(String password) {
        boolean hasNum = false;
        boolean hasCap = false;
        boolean hasSchar = false;

        if (password.length() >= 8) {
            for (char current : password.toCharArray()) {
                if (Character.isUpperCase(current)) hasCap = true;
                if (Character.isDigit(current)) hasNum = true;
                if (!Character.isLetterOrDigit(current)) hasSchar = true;
            }
            return hasNum && hasSchar && hasCap;
        }
        return false;
    }
//Achieve message for succesful entry or unsucsseful entry
    public String registerUser(String username, String password, String Number) {
        String passMessage = "Password successfully captured";
        String nameMessage = "Username successfully captured";
        String phoneMessage = "Phone number successfully captured";
        return passMessage + "\n" + nameMessage + "\n" + phoneMessage;
    }

    public static boolean LoginUser(boolean checkUser, boolean checkPass) {
        if (!checkPass || !checkUser) return false;
        String uSER = JOptionPane.showInputDialog("Enter your username:");
        String pASS = JOptionPane.showInputDialog("   your password:");
        return pASS.equals(Login.class) && uSER.equals(Login.class);
    }

    public String returnLoginStatus(boolean regStatus, String name, String surName) {
        return regStatus ? "Welcome " + name + " " + surName + ", it is great to see you again!" : "Username or password incorrect, please try again";
    }

    public static boolean checkPhoneNumber(String num) {
        return num.matches("(27[+27-9]{9})");
    }
}
